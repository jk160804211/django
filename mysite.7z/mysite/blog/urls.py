from django.urls import path
from .views import blog_detail,blog_with_type,blog_dates
urlpatterns = [
   path('<int:blog_pk>',blog_detail,name="blog_detail"),
   path('type/<int:blog_type>',blog_with_type,name='blog_type'),
   path('dates/<int:year>/<int:month>',blog_dates,name='blog_dates'),
]