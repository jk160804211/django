from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class BlogType(models.Model):
	type_name=models.CharField(max_length=15)
	flag=models.CharField(max_length=30,default="collapseOne")
	
	def __str__(self):
	 	return self.type_name

class Blog(models.Model):
	title=models.CharField(max_length=50)
	blog_type=models.ForeignKey(BlogType,on_delete=models.DO_NOTHING)
	content=models.TextField()
	author=models.ForeignKey(User,on_delete=models.DO_NOTHING)
	createTime=models.DateTimeField(auto_now_add=True)
	endTime=models.DateTimeField(auto_now=True)

	class Meta:
		ordering=['-createTime']

	def __str__(self):
		return "<blog: %s>" % self.title
