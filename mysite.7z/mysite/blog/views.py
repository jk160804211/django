from django.shortcuts import render_to_response,get_object_or_404
from .models import Blog,BlogType
from django.core.paginator import Paginator
from django.conf import settings
# Create your views here.

def my_paginator(blogs,page_num):
	paginator=Paginator(blogs,settings.EACH_PAGE_NUMBER)
	page_of_blogs=paginator.get_page(page_num)
	page_lists=list(range(max(page_of_blogs.number-2,1),page_of_blogs.number))+ \
	list(range(page_of_blogs.number,min(page_of_blogs.number+2,paginator.num_pages)+1))
	if page_lists[0]-1>2:
		page_lists.insert(0,'...')
	if paginator.num_pages-page_lists[-1]>2:
		page_lists.append('...')

	if page_lists[0]!=1:
		page_lists.insert(0,1)
	if page_lists[-1]!=paginator.num_pages:
		page_lists.append(paginator.num_pages)

	contest={}
	contest['page_of_blogs']=page_of_blogs
	contest['paginator']=page_lists
	return contest



def blog_list(request):
	blogs=Blog.objects.all()
	paginator=Paginator(blogs,10)
	page_num=request.GET.get('page',1)
	page_of_blogs=paginator.get_page(page_num)
	context={}
	context['page_of_blogs']=page_of_blogs
	context['blog_types']=BlogType.objects.all()
	return render_to_response('blog_list.html',context)

def blog_detail(request,blog_pk):
	blog=get_object_or_404(Blog,pk=blog_pk)
	context={}
	context['blog']=blog
	context['blog_types']=BlogType.objects.all()
	context['previous_blog']=Blog.objects.all().filter(createTime__gt=blog.createTime).last()
	context['next_blog']=Blog.objects.all().filter(createTime__lt=blog.createTime).first()
	context['blog_dates']=Blog.objects.dates('createTime','month',order='DESC')
	return render_to_response('detail.html',context)

def blog_with_type(request,blog_type):
	blogType=get_object_or_404(BlogType,pk=blog_type)
	blogs=Blog.objects.all().filter(blog_type=blogType)
	page_num=request.GET.get('page',1)
	contest=my_paginator(blogs,page_num)
	contest['blogType']=blogType
	contest['blogTypes']=BlogType.objects.all()
	contest['blog_dates']=Blog.objects.dates('createTime','month',order='DESC')
	return render_to_response('blog_with_type.html',contest)

def blog_dates(request,year,month):
	blogs=Blog.objects.all().filter(createTime__year=year,createTime__month=month)
	page_num=request.GET.get('page',1)
	contest=my_paginator(blogs,page_num)
	contest['year']=year
	contest['month']=month
	contest['blogTypes']=BlogType.objects.all()
	contest['blog_dates']=Blog.objects.dates('createTime','month',order='DESC')

	return render_to_response('blog_with_time.html',contest)
